/* جسر التطبيق (أندرويد): يربط ميزات الموقع بالنظام. لا يعمل على المتصفح العادي. */
(function(){
  'use strict';
  var SITE = 'https://relaxed-bavarois-829457.netlify.app';
  /* رابط المشاركة (زر «مشاركة التطبيق»). غيّريه لرابط قناة التلجرام عند توفره. */
  var SHARE_URL = SITE + '/';
  window.MALAZ_SHARE_URL = SHARE_URL;

  var C = window.Capacitor;
  var native = !!(C && ((C.isNativePlatform && C.isNativePlatform()) || (C.getPlatform && C.getPlatform() !== 'web')));
  if(!native) return;

  function plugin(n){ try { return C.registerPlugin(n); } catch(e){ return null; } }
  var FS = plugin('Filesystem'), SH = plugin('Share'), LN = plugin('LocalNotifications'), PR = plugin('PrintHtml');
  function toast(m){ try { if(typeof window.showToast === 'function') window.showToast(m); } catch(e){} }
  function isCancel(e){ return !!(e && /cancel/i.test(String(e.message || e))); }

  /* ---------- تحويل الملفات وحفظها مؤقتاً ---------- */
  function blobToBase64(blob){
    return new Promise(function(res, rej){
      var r = new FileReader();
      r.onload = function(){ var s = String(r.result); res(s.slice(s.indexOf(',') + 1)); };
      r.onerror = function(){ rej(r.error); };
      r.readAsDataURL(blob);
    });
  }
  function safeName(n){ return String(n || 'file').replace(/[\\\/:*?"<>|\s]+/g, '_'); }
  async function saveToCache(blob, name){
    var data = await blobToBase64(blob);
    var r = await FS.writeFile({ path: 'share/' + Date.now() + '/' + safeName(name), data: data, directory: 'CACHE', recursive: true });
    return r.uri;
  }

  try { if(FS) FS.rmdir({ path: 'share', directory: 'CACHE', recursive: true }).catch(function(){}); } catch(e){}

  /* ---------- 1) التنزيل (نسخة احتياطية، CSV، صور الشهادات...) ---------- */
  var origClick = HTMLAnchorElement.prototype.click;
  HTMLAnchorElement.prototype.click = function(){
    var a = this, href = a.href || '';
    if(a.hasAttribute('download') && /^(blob:|data:)/.test(href) && FS && SH){
      var name = a.getAttribute('download') || 'file';
      (async function(){
        try {
          var blob = await (await fetch(href)).blob();
          var uri = await saveToCache(blob, name);
          await SH.share({ title: name, dialogTitle: 'حفظ أو مشاركة الملف', files: [uri] });
        } catch(e){
          if(isCancel(e)) return;
          console.warn('download bridge failed', e);
          toast('⚠️ تعذّر حفظ الملف');
        }
      })();
      return;
    }
    return origClick.apply(this, arguments);
  };

  /* ---------- 2) المشاركة (مع الصور والملفات) ---------- */
  async function nativeShare(data){
    data = data || {};
    var files = [];
    if(data.files && data.files.length){
      for(var i = 0; i < data.files.length; i++){
        var f = data.files[i];
        files.push(await saveToCache(f, f.name || ('file' + i)));
      }
    }
    var o = { dialogTitle: data.title || 'مشاركة' };
    if(data.title) o.title = data.title;
    if(data.text) o.text = data.text;
    if(data.url && !(data.text && String(data.text).indexOf(data.url) !== -1)) o.url = data.url;
    if(files.length) o.files = files;
    try { await SH.share(o); }
    catch(e){
      if(isCancel(e)){ var err = new Error('Share canceled'); err.name = 'AbortError'; throw err; }
      throw e;
    }
  }
  if(SH && FS){
    try {
      Object.defineProperty(navigator, 'share', { value: nativeShare, configurable: true, writable: true });
      Object.defineProperty(navigator, 'canShare', { value: function(){ return true; }, configurable: true, writable: true });
    } catch(e){ console.warn('share shim failed', e); }
  }

  /* ---------- 3) الطباعة + الروابط النسبية ---------- */
  var origOpen = window.open.bind(window);
  function doPrint(html){
    if(!PR){ toast('⚠️ الطباعة غير متاحة'); return; }
    PR.print({ html: html, name: 'ملاذ_المعلم' }).catch(function(){ toast('⚠️ تعذّرت الطباعة'); });
  }
  window.open = function(url, target, features){
    if(url === '' || url == null || url === 'about:blank'){
      var buf = [];
      return {
        closed: false,
        document: {
          write: function(h){ buf.push(String(h)); },
          writeln: function(h){ buf.push(String(h) + '\n'); },
          open: function(){}, close: function(){}
        },
        focus: function(){}, blur: function(){}, close: function(){ this.closed = true; },
        print: function(){ doPrint(buf.join('')); }
      };
    }
    if(!/^[a-z][a-z0-9+.\-]*:/i.test(String(url))) url = SITE + '/' + String(url).replace(/^\.?\//, '');
    return origOpen(url, target, features);
  };

  /* ---------- 4) الإشعارات ---------- */
  if(LN){
    var NN = function(title, opts){
      try {
        LN.schedule({ notifications: [{ id: Math.floor(Math.random() * 2000000000), title: String(title || ''), body: String((opts && opts.body) || '') }] }).catch(function(){});
      } catch(e){}
    };
    NN.permission = 'default';
    NN.requestPermission = function(){
      return LN.requestPermissions().then(function(r){
        NN.permission = (r && r.display === 'granted') ? 'granted' : 'denied';
        return NN.permission;
      }).catch(function(){ NN.permission = 'denied'; return 'denied'; });
    };
    try { LN.checkPermissions().then(function(r){ if(r && r.display === 'granted') NN.permission = 'granted'; }).catch(function(){}); } catch(e){}
    window.Notification = NN;
  }

  /* ---------- 5) لا حاجة لـ Service Worker داخل التطبيق ---------- */
  try {
    if('serviceWorker' in navigator){
      navigator.serviceWorker.getRegistrations().then(function(rs){ rs.forEach(function(r){ r.unregister(); }); }).catch(function(){});
    }
    if(window.caches && caches.keys){ caches.keys().then(function(ks){ ks.forEach(function(k){ caches.delete(k); }); }).catch(function(){}); }
  } catch(e){}

  /* ---------- 6) تحميل خط Cairo مسبقاً (للشهادات والصور) ---------- */
  document.addEventListener('DOMContentLoaded', function(){
    try { if(document.fonts && document.fonts.load){ ['400','500','600','700','800','900'].forEach(function(w){ document.fonts.load(w + ' 16px Cairo').catch(function(){}); }); } } catch(e){}
  });
})();
